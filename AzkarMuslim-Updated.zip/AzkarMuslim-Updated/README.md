# أذكار المسلم

Android app built with Kotlin and Jetpack Compose.

## Build requirements
- JDK 17 (use the embedded JDK 17 in Android Studio)
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Android SDK 35

Java source/target compatibility and Kotlin JVM target are both set to 17. Java 18 is not required.

## Build APK
From this directory run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
