package com.example.azkarmuslim

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

private val Teal = Color(0xFF087B45)
private val PaleGreen = Color(0xFFE9F8D8)
private val SoftMint = Color(0xFFE7FFE9)
private data class Dhikr(val text: String, val target: Int, val count: Int = 0)
private data class DhikrImage(val uri: String, val target: Int = 33, val count: Int = 0)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("azkar", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val initial = listOf(
            Dhikr("سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", 100),
            Dhikr("سُبْحَانَ اللَّهِ الْعَظِيمِ", 100),
            Dhikr("لَا إِلَهَ إِلَّا اللَّهُ", 100),
            Dhikr("الْحَمْدُ لِلَّهِ", 33),
            Dhikr("اللَّهُ أَكْبَرُ", 33),
            Dhikr("أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", 100),
            Dhikr("اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", 10),
            Dhikr("لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", 100),
            Dhikr("اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ", 3),
            Dhikr("رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ نَبِيًّا", 3),
            Dhikr("بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", 3),
            Dhikr("اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ", 1)
        )
        val loaded = try {
            prefs.getString("items", null)?.let { saved -> JSONArray(saved).let { a ->
                (0 until a.length()).map { i -> a.getJSONObject(i).let { Dhikr(it.getString("text"), it.getInt("target"), it.getInt("count")) } }
            } } ?: initial
        } catch (_: Exception) { initial }
        val photos = try {
            prefs.getString("photo_items", null)?.let { saved -> JSONArray(saved).let { a ->
                (0 until a.length()).map { i -> a.getJSONObject(i).let { DhikrImage(it.getString("uri"), it.optInt("target", 33), it.optInt("count", 0)) } }
            } } ?: emptyList()
        } catch (_: Exception) { emptyList() }
        setContent { AzkarApp(loaded, photos, { saveAzkar(it) }, { savePhotos(it) }) }
    }
    private fun saveAzkar(list: List<Dhikr>) {
        val a = JSONArray(); list.forEach { a.put(JSONObject().put("text", it.text).put("target", it.target).put("count", it.count)) }
        prefs.edit().putString("items", a.toString()).apply()
    }
    private fun savePhotos(list: List<DhikrImage>) {
        val a = JSONArray(); list.forEach { a.put(JSONObject().put("uri", it.uri).put("target", it.target).put("count", it.count)) }
        prefs.edit().putString("photo_items", a.toString()).apply()
    }
}

@Composable
private fun AzkarApp(start: List<Dhikr>, startPhotos: List<DhikrImage>, onSave: (List<Dhikr>) -> Unit, onSavePhotos: (List<DhikrImage>) -> Unit) {
    val context = LocalContext.current
    var items by remember { mutableStateOf(start) }
    var photos by remember { mutableStateOf(startPhotos) }
    var selected by remember { mutableIntStateOf(0) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableIntStateOf(-1) }
    var text by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("100") }
    fun update(newItems: List<Dhikr>) { items = newItems; onSave(newItems); if (selected >= items.size) selected = (items.size - 1).coerceAtLeast(0) }
    fun updatePhotos(newPhotos: List<DhikrImage>) { photos = newPhotos; onSavePhotos(newPhotos) }
    var editingPhoto by remember { mutableIntStateOf(-1) }
    var photoTarget by remember { mutableStateOf("33") }
    var photoMenu by remember { mutableIntStateOf(-1) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val extension = context.contentResolver.getType(uri)?.substringAfterLast('/')?.let { ".$it" } ?: ".img"
                val destination = File(context.filesDir, "azkar_${UUID.randomUUID()}$extension")
                context.contentResolver.openInputStream(uri)?.use { input -> destination.outputStream().use { output -> input.copyTo(output) } }
                if (destination.exists() && destination.length() > 0L) {
                    updatePhotos(photos + DhikrImage(Uri.fromFile(destination).toString()))
                }
            } catch (_: Exception) { }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Teal)) {
        Column(Modifier.fillMaxSize().background(SoftMint).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("أذكار المسلم", fontSize = 32.sp, color = Teal, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp, bottom = 10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { selectedTab = 0 }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (selectedTab == 0) Teal else Color.LightGray)) { Text("الأذكار") }
                Button(onClick = { selectedTab = 1 }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (selectedTab == 1) Teal else Color.LightGray)) { Text("صور الأذكار") }
            }
            Spacer(Modifier.height(10.dp))
            if (selectedTab == 0) {
                if (items.isNotEmpty()) {
                    val safeSelected = selected.coerceIn(items.indices)
                    val current = items[safeSelected]
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Spacer(Modifier.height(6.dp))
                            Text(current.text, fontSize = 25.sp, lineHeight = 42.sp, textAlign = TextAlign.Center, color = Color(0xFF151515), modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                            Spacer(Modifier.height(10.dp))
                            Box(
                                modifier = Modifier.size(142.dp)
                                    .background(PaleGreen, CircleShape)
                                    .border(3.dp, Teal, CircleShape)
                                    .then(Modifier.clickable {
                                        val n = items.toMutableList()
                                        val d = n[safeSelected]
                                        n[safeSelected] = d.copy(count = if (d.count + 1 >= d.target) 0 else d.count + 1)
                                        update(n)
                                    })
                                    .then(Modifier.padding(5.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                androidx.compose.foundation.layout.Box(
                                    Modifier.fillMaxSize().background(PaleGreen, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("${current.count}", fontSize = 42.sp, color = Teal, fontWeight = FontWeight.ExtraBold)
                                        Text("/ ${current.target}", fontSize = 23.sp, color = Color(0xFF101810), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { val n=items.toMutableList(); n[safeSelected]=n[safeSelected].copy(count=0); update(n) }, modifier=Modifier.weight(1f), border=BorderStroke(1.5.dp, Teal)) { Text("إعادة العداد", color=Teal) }
                                OutlinedButton(onClick = { selected = (safeSelected - 1 + items.size) % items.size }, modifier=Modifier.weight(1f), border=BorderStroke(1.5.dp, Teal)) { Text("السابق", color=Teal) }
                                OutlinedButton(onClick = { selected = (safeSelected + 1) % items.size }, modifier=Modifier.weight(1f), border=BorderStroke(1.5.dp, Teal)) { Text("التالي", color=Teal) }
                            }
                        }
                    }
                } else Text("لا توجد أذكار. أضف ذكرًا للبدء.", modifier = Modifier.padding(30.dp))
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { editing=-1; text=""; target="100"; showEditor=true }, modifier=Modifier.weight(1f)) { Text("＋ إضافة ذكر") }
                    OutlinedButton(onClick = { if (items.isNotEmpty()) { editing=selected; text=items[selected].text; target=items[selected].target.toString(); showEditor=true } }, modifier=Modifier.weight(1f), enabled=items.isNotEmpty()) { Text("تعديل") }
                    OutlinedButton(onClick = { if (items.isNotEmpty()) { val n=items.toMutableList(); n.removeAt(selected); update(n) } }, enabled=items.isNotEmpty()) { Text("حذف") }
                }
                Text("قائمة الأذكار", color=Teal, fontWeight=FontWeight.Bold, fontSize=17.sp, modifier=Modifier.align(Alignment.End).padding(4.dp))
                LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                    itemsIndexed(items) { index, d ->
                        Card(Modifier.fillMaxWidth().padding(vertical=3.dp).clickable { selected=index }, colors=CardDefaults.cardColors(containerColor=if(index==selected) Color(0xFFD1E9E6) else Color.White)) {
                            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment=Alignment.CenterVertically) {
                                Text("${d.count}/${d.target}", color=Teal, fontWeight=FontWeight.Bold, fontSize=13.sp)
                                Spacer(Modifier.width(10.dp)); Text(d.text, modifier=Modifier.weight(1f), textAlign=TextAlign.End, fontSize=15.sp, lineHeight=24.sp)
                            }
                        }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("صور الأذكار", color = Teal, fontWeight = FontWeight.Bold)
                    Button(onClick = { imagePicker.launch(arrayOf("image/*")) }) { Text("＋ إضافة صورة") }
                }
                if (photos.isEmpty()) Text("أضف صور الأذكار من معرض الصور على هاتفك", color = Color.DarkGray, modifier = Modifier.padding(24.dp))
                LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                    itemsIndexed(photos) { index, photo ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                DhikrPhoto(photo.uri, Modifier.fillMaxWidth().heightIn(max = 360.dp))
                                Spacer(Modifier.height(6.dp))
                                Box(
                                    Modifier.size(112.dp).background(PaleGreen, CircleShape)
                                        .border(3.dp, Teal, CircleShape)
                                        .clickable {
                                            val n = photos.toMutableList(); val p = n[index]
                                            n[index] = p.copy(count = if (p.count + 1 >= p.target) 0 else p.count + 1)
                                            updatePhotos(n)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("${photo.count}", color = Teal, fontWeight = FontWeight.ExtraBold, fontSize = 32.sp)
                                        Text("/ ${photo.target}", color = Color(0xFF101810), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                                    Box {
                                        TextButton(onClick = { photoMenu = index }) { Text("⋮ المزيد") }
                                        DropdownMenu(expanded = photoMenu == index, onDismissRequest = { photoMenu = -1 }) {
                                            DropdownMenuItem(text = { Text("تغيير الهدف") }, onClick = { photoTarget=photo.target.toString(); editingPhoto=index; photoMenu=-1 })
                                            DropdownMenuItem(text = { Text("تصفير العداد") }, onClick = { val n=photos.toMutableList(); n[index]=n[index].copy(count=0); updatePhotos(n); photoMenu=-1 })
                                            DropdownMenuItem(text = { Text("حذف الصورة") }, onClick = {
                                                val old = photos[index].uri
                                                updatePhotos(photos.filterIndexed { i, _ -> i != index })
                                                try { File(Uri.parse(old).path ?: "").delete() } catch (_: Exception) { }
                                                photoMenu=-1
                                            })
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showEditor) AlertDialog(
            onDismissRequest = { showEditor=false }, title = { Text(if(editing<0) "إضافة ذكر" else "تعديل الذكر") },
            text = { Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value=text, onValueChange={text=it}, label={Text("نص الذكر")}, modifier=Modifier.fillMaxWidth())
                OutlinedTextField(value=target, onValueChange={target=it.filter(Char::isDigit)}, label={Text("عدد التكرار")}, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number), modifier=Modifier.fillMaxWidth())
            } },
            confirmButton = { TextButton(onClick={ val count=target.toIntOrNull()?.coerceAtLeast(1) ?: 33
                if(text.isNotBlank()) { val n=items.toMutableList(); if(editing<0) { n.add(Dhikr(text.trim(),count)); selected=n.lastIndex } else n[editing]=n[editing].copy(text=text.trim(),target=count,count=0); update(n) }; showEditor=false
            }) { Text("حفظ") } }, dismissButton = { TextButton(onClick={showEditor=false}) { Text("إلغاء") } }
        )
        if (editingPhoto >= 0) AlertDialog(
            onDismissRequest = { editingPhoto = -1 },
            title = { Text("تغيير هدف التسبيح") },
            text = { OutlinedTextField(value = photoTarget, onValueChange = { photoTarget = it.filter(Char::isDigit) }, label = { Text("عدد التكرار") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) },
            confirmButton = { TextButton(onClick = {
                val n = photos.toMutableList()
                if (editingPhoto in n.indices) n[editingPhoto] = n[editingPhoto].copy(target = photoTarget.toIntOrNull()?.coerceAtLeast(1) ?: 33, count = 0)
                updatePhotos(n); editingPhoto = -1
            }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { editingPhoto = -1 }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun DhikrPhoto(uri: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = uri) {
        value = withContext(Dispatchers.IO) {
            try { context.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
        }
    }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "صورة ذكر", modifier = modifier)
    else Box(modifier.background(Color(0xFFF3F3F3)), contentAlignment = Alignment.Center) { Text("تعذر فتح الصورة", color = Color.Gray, modifier = Modifier.padding(24.dp)) }
}
