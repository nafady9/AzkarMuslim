AzkarMuslim GitHub build bundle

Upload these items to the ROOT of your GitHub repository:
- AzkarMuslim-Updated.zip
- .github/workflows/android.yml (replace the existing workflow file)

Then open Actions and run "Build Azkar Muslim APK".
The workflow extracts the complete Android project and builds the debug APK with Java 17.
