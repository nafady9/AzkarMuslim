package com.example.azkarmuslim

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject

private val Teal = Color(0xFF287A72)
private data class Dhikr(
    val text: String,
    val target: Int,
    val count: Int = 0,
    val imageUri: String? = null
)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("azkar", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val initial = listOf(
            Dhikr("سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", 100),
            Dhikr("سُبْحَانَ اللَّهِ الْعَظِيمِ", 100),
            Dhikr("لَا إِلَهَ إِلَّا اللَّهُ", 100),
            Dhikr("الْحَمْدُ لِلَّهِ", 33),
            Dhikr("اللَّهُ أَكْبَرُ", 33),
            Dhikr("أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", 100),
            Dhikr("اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", 10),
            Dhikr("لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", 100),
            Dhikr("اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ", 3),
            Dhikr("رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ نَبِيًّا", 3),
            Dhikr("بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", 3),
            Dhikr("اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ", 1)
        )
        val saved = prefs.getString("items", null)
        val loaded = try {
            if (saved == null) initial else JSONArray(saved).let { arr ->
                (0 until arr.length()).map { i ->
                    arr.getJSONObject(i).let {
                        Dhikr(
                            it.optString("text", ""),
                            it.optInt("target", 33).coerceAtLeast(1),
                            it.optInt("count", 0).coerceAtLeast(0),
                            it.optString("imageUri", "").takeIf(String::isNotBlank)
                        )
                    }
                }
            }
        } catch (_: Exception) { initial }
        setContent { AzkarApp(loaded) { list -> save(list) } }
    }

    private fun save(list: List<Dhikr>) {
        val arr = JSONArray()
        list.forEach { d ->
            arr.put(JSONObject().put("text", d.text).put("target", d.target)
                .put("count", d.count).put("imageUri", d.imageUri ?: ""))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}

@Composable
private fun AzkarApp(start: List<Dhikr>, onSave: (List<Dhikr>) -> Unit) {
    var items by remember { mutableStateOf(start) }
    var selected by remember { mutableIntStateOf(0) }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableIntStateOf(-1) }
    var text by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("100") }
    var imageUri by remember { mutableStateOf<String?>(null) }
    var menuFor by remember { mutableIntStateOf(-1) }
    var deleteFor by remember { mutableIntStateOf(-1) }

    fun update(newItems: List<Dhikr>) {
        items = newItems
        onSave(newItems)
        if (items.isEmpty()) selected = 0
        else if (selected >= items.size) selected = items.lastIndex
    }

    val context = androidx.compose.ui.platform.LocalContext.current
    val persistentImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            imageUri = it.toString()
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Teal)) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFFE5F3F2)).padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("أذكار المسلم", fontSize = 28.sp, color = Teal, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
            Text("أذكاري الخاصة", color = Color.DarkGray, fontSize = 14.sp)
            Spacer(Modifier.height(14.dp))

            if (items.isNotEmpty()) {
                val safeIndex = selected.coerceIn(items.indices)
                val current = items[safeIndex]
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${safeIndex + 1} / ${items.size}", color = Teal, fontWeight = FontWeight.Bold)
                            Text("الذكر الحالي", color = Color.Gray)
                        }
                        Spacer(Modifier.height(18.dp))
                        if (current.imageUri != null) {
                            AsyncImage(model = current.imageUri, contentDescription = "صورة الذكر",
                                modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp))
                        } else {
                            Text(current.text, fontSize = 25.sp, lineHeight = 42.sp,
                                textAlign = TextAlign.Center, color = Color(0xFF151515),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("${current.count} / ${current.target}", fontSize = 30.sp,
                            color = Teal, fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(
                            progress = { (current.count.toFloat() / current.target.coerceAtLeast(1)).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp), color = Teal)
                        Button(onClick = {
                            val next = items.toMutableList()
                            val d = next[safeIndex]
                            if (d.count < d.target) next[safeIndex] = d.copy(count = d.count + 1)
                            update(next)
                        }, modifier = Modifier.fillMaxWidth().height(58.dp),
                            shape = RoundedCornerShape(14.dp)) { Text("تسبيح  +1", fontSize = 21.sp) }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val n = items.toMutableList(); n[safeIndex] = n[safeIndex].copy(count = 0); update(n)
                            }) { Text("إعادة العداد") }
                            OutlinedButton(onClick = { if (safeIndex > 0) selected-- }) { Text("السابق") }
                            OutlinedButton(onClick = { if (safeIndex < items.lastIndex) selected++ }) { Text("التالي") }
                        }
                    }
                }
            } else Text("لا توجد أذكار. أضف ذكرًا من قائمة الثلاث نقاط.", modifier = Modifier.padding(30.dp))

            Spacer(Modifier.height(12.dp))
            Text("قائمة الأذكار", color = Teal, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.End).padding(4.dp))
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                itemsIndexed(items) { index, d ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .clickable { selected = index },
                        colors = CardDefaults.cardColors(containerColor =
                            if (index == selected) Color(0xFFD1E9E6) else Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${d.count}/${d.target}", color = Teal, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(10.dp))
                            if (d.imageUri != null) {
                                AsyncImage(model = d.imageUri, contentDescription = "صورة الذكر",
                                    modifier = Modifier.size(54.dp))
                            } else {
                                Text(d.text, modifier = Modifier.weight(1f), textAlign = TextAlign.End,
                                    fontSize = 15.sp, lineHeight = 24.sp, maxLines = 2)
                            }
                            Box {
                                IconButton(onClick = { menuFor = index }) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "خيارات الذكر", tint = Teal)
                                }
                                DropdownMenu(expanded = menuFor == index, onDismissRequest = { menuFor = -1 }) {
                                    DropdownMenuItem(text = { Text("تعديل الذكر والعدد") }, onClick = {
                                        editing = index; text = d.text; target = d.target.toString()
                                        imageUri = d.imageUri; showEditor = true; menuFor = -1
                                    })
                                    DropdownMenuItem(text = { Text("تغيير صورة الذكر") }, onClick = {
                                        selected = index; editing = index; text = d.text
                                        target = d.target.toString(); imageUri = d.imageUri
                                        showEditor = true; menuFor = -1
                                    })
                                    DropdownMenuItem(text = { Text("حذف الذكر") }, onClick = {
                                        deleteFor = index; menuFor = -1
                                    })
                                    DropdownMenuItem(text = { Text("إعادة العداد") }, onClick = {
                                        val n = items.toMutableList(); n[index] = n[index].copy(count = 0)
                                        update(n); menuFor = -1
                                    })
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                editing = -1; text = ""; target = "100"; imageUri = null; showEditor = true
            }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة ذكر جديد") }
        }

        if (showEditor) AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editing < 0) "إضافة ذكر" else "تعديل الذكر") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = text, onValueChange = { text = it },
                        label = { Text("نص الذكر (اختياري إذا أضفت صورة)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = target, onValueChange = { target = it.filter(Char::isDigit) },
                        label = { Text("عدد التكرار المطلوب") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth())
                    Text("العدد قابل للتغيير لكل ذكر بصورة مستقلة.", color = Teal, fontSize = 12.sp)
                    OutlinedButton(onClick = { persistentImagePicker.launch(arrayOf("image/*")) },
                        modifier = Modifier.fillMaxWidth()) { Text(if (imageUri == null) "اختيار صورة للذكر" else "تغيير الصورة") }
                    if (imageUri != null) {
                        AsyncImage(model = imageUri, contentDescription = "معاينة صورة الذكر",
                            modifier = Modifier.fillMaxWidth().heightIn(max = 130.dp))
                        TextButton(onClick = { imageUri = null }) { Text("إزالة الصورة") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val countTarget = target.toIntOrNull()?.coerceAtLeast(1) ?: 100
                    if (text.isNotBlank() || imageUri != null) {
                        val n = items.toMutableList()
                        if (editing < 0) {
                            n.add(Dhikr(text.trim(), countTarget, 0, imageUri)); selected = n.lastIndex
                        } else {
                            val old = n[editing]
                            n[editing] = old.copy(text = text.trim(), target = countTarget,
                                count = if (old.target != countTarget) 0 else old.count, imageUri = imageUri)
                        }
                        update(n)
                    }
                    showEditor = false
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text("إلغاء") } }
        )

        if (deleteFor >= 0) AlertDialog(
            onDismissRequest = { deleteFor = -1 },
            title = { Text("حذف الذكر؟") },
            text = { Text("سيتم حذف هذا الذكر والعداد الخاص به.") },
            confirmButton = {
                TextButton(onClick = {
                    val n = items.toMutableList()
                    if (deleteFor in n.indices) n.removeAt(deleteFor)
                    update(n); deleteFor = -1
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { deleteFor = -1 }) { Text("إلغاء") } }
        )
    }
}
