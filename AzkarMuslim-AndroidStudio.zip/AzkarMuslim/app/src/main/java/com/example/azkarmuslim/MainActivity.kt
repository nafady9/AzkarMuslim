package com.example.azkarmuslim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Teal = Color(0xFF287A72)
private data class Dhikr(val text: String, val target: Int, val count: Int = 0)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("azkar", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val initial = listOf(
            Dhikr("سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", 100),
            Dhikr("سُبْحَانَ اللَّهِ الْعَظِيمِ", 100),
            Dhikr("لَا إِلَهَ إِلَّا اللَّهُ", 100),
            Dhikr("الْحَمْدُ لِلَّهِ", 33),
            Dhikr("اللَّهُ أَكْبَرُ", 33),
            Dhikr("أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", 100),
            Dhikr("اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", 10),
            Dhikr("لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", 100),
            Dhikr("اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ", 3),
            Dhikr("رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ نَبِيًّا", 3),
            Dhikr("بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", 3),
            Dhikr("اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ", 1)
        )
        val saved = prefs.getString("items", null)
        val loaded = try {
            if (saved == null) initial else JSONArray(saved).let { arr ->
                (0 until arr.length()).map { i -> arr.getJSONObject(i).let { Dhikr(it.getString("text"), it.getInt("target"), it.getInt("count")) } }
            }
        } catch (_: Exception) { initial }
        setContent { AzkarApp(loaded) { list -> save(list) } }
    }
    private fun save(list: List<Dhikr>) {
        val arr = JSONArray()
        list.forEach { d -> arr.put(JSONObject().put("text", d.text).put("target", d.target).put("count", d.count)) }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}

@Composable
private fun AzkarApp(start: List<Dhikr>, onSave: (List<Dhikr>) -> Unit) {
    var items by remember { mutableStateOf(start) }
    var selected by remember { mutableIntStateOf(0) }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableIntStateOf(-1) }
    var text by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("33") }
    fun update(newItems: List<Dhikr>) { items = newItems; onSave(newItems); if (selected >= items.size) selected = (items.size - 1).coerceAtLeast(0) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Teal)) {
        Column(Modifier.fillMaxSize().background(Color(0xFFE5F3F2)).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("أذكار المسلم", fontSize = 28.sp, color = Teal, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
            Text("أذكاري الخاصة", color = Color.DarkGray, fontSize = 14.sp)
            Spacer(Modifier.height(14.dp))
            if (items.isNotEmpty()) {
                val current = items[selected.coerceIn(items.indices)]
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${selected + 1} / ${items.size}", color = Teal, fontWeight = FontWeight.Bold)
                            Text("الذكر الحالي", color = Color.Gray)
                        }
                        Spacer(Modifier.height(24.dp))
                        Text(current.text, fontSize = 27.sp, lineHeight = 46.sp, textAlign = TextAlign.Center, color = Color(0xFF151515), modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
                        Spacer(Modifier.height(18.dp))
                        Text("${current.count} / ${current.target}", fontSize = 30.sp, color = Teal, fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(progress = { (current.count.toFloat() / current.target.coerceAtLeast(1)).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp), color = Teal)
                        Button(onClick = {
                            val next = items.toMutableList(); val c = next[selected]
                            if (c.count < c.target) next[selected] = c.copy(count = c.count + 1)
                            update(next)
                            if (next[selected].count >= next[selected].target && selected < next.lastIndex) selected++
                        }, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(14.dp)) { Text("تسبيح  +1", fontSize = 21.sp) }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { val n=items.toMutableList(); n[selected]=n[selected].copy(count=0); update(n) }) { Text("إعادة العداد") }
                            OutlinedButton(onClick = { if (selected > 0) selected-- }) { Text("السابق") }
                            OutlinedButton(onClick = { if (selected < items.lastIndex) selected++ }) { Text("التالي") }
                        }
                    }
                }
            } else Text("لا توجد أذكار. أضف ذكرًا للبدء.", modifier = Modifier.padding(30.dp))

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { editing=-1; text=""; target="33"; showEditor=true }, modifier=Modifier.weight(1f)) { Text("＋ إضافة ذكر") }
                OutlinedButton(onClick = { if (items.isNotEmpty()) { editing=selected; text=items[selected].text; target=items[selected].target.toString(); showEditor=true } }, modifier=Modifier.weight(1f), enabled=items.isNotEmpty()) { Text("تعديل") }
                OutlinedButton(onClick = { if (items.isNotEmpty()) { val n=items.toMutableList(); n.removeAt(selected); update(n) } }, enabled=items.isNotEmpty()) { Text("حذف") }
            }
            Spacer(Modifier.height(12.dp))
            Text("قائمة الأذكار", color=Teal, fontWeight=FontWeight.Bold, fontSize=18.sp, modifier=Modifier.align(Alignment.End).padding(4.dp))
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                itemsIndexed(items) { index, d ->
                    Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable { selected=index }, colors=CardDefaults.cardColors(containerColor=if(index==selected) Color(0xFFD1E9E6) else Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                            Text("${d.count}/${d.target}", color=Teal, fontWeight=FontWeight.Bold)
                            Spacer(Modifier.width(12.dp))
                            Text(d.text, modifier=Modifier.weight(1f), textAlign=TextAlign.End, fontSize=16.sp, lineHeight=27.sp)
                        }
                    }
                }
            }
        }
        if (showEditor) AlertDialog(
            onDismissRequest = { showEditor=false },
            title = { Text(if(editing<0) "إضافة ذكر" else "تعديل الذكر") },
            text = { Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value=text, onValueChange={text=it}, label={Text("نص الذكر")}, modifier=Modifier.fillMaxWidth())
                OutlinedTextField(value=target, onValueChange={target=it.filter(Char::isDigit)}, label={Text("عدد التكرار")}, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number), modifier=Modifier.fillMaxWidth())
            } },
            confirmButton = { TextButton(onClick={
                val count=target.toIntOrNull()?.coerceAtLeast(1) ?: 33
                if(text.isNotBlank()) { val n=items.toMutableList(); if(editing<0) { n.add(Dhikr(text.trim(),count)); selected=n.lastIndex } else n[editing]=n[editing].copy(text=text.trim(),target=count,count=0); update(n) }
                showEditor=false
            }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick={showEditor=false}) { Text("إلغاء") } }
        )
    }
}
