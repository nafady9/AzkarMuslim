ارفع هذين العنصرين إلى المستودع nafady9/AzkarMuslim مع استبدال الملفين عند الطلب:
1) AzkarMuslim-AndroidStudio-v1.2.zip إلى جذر المستودع.
2) .github/workflows/android.yml إلى نفس المسار في المستودع.
بعد الرفع افتح Actions ثم Build Azkar Muslim APK ثم Run workflow.
بعد نجاح البناء افتح نتيجة التشغيل ونزّل Artifact باسم AzkarMuslim-APK.
