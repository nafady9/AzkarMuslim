package com.example.azkarmuslim

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

private val Teal = Color(0xFF287A72)
private data class Dhikr(val text: String, val target: Int, val count: Int = 0)
private data class DhikrImage(val uri: String, val target: Int = 33, val count: Int = 0)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("azkar", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val initial = listOf(
            Dhikr("سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", 100),
            Dhikr("سُبْحَانَ اللَّهِ الْعَظِيمِ", 100),
            Dhikr("لَا إِلَهَ إِلَّا اللَّهُ", 100),
            Dhikr("الْحَمْدُ لِلَّهِ", 33),
            Dhikr("اللَّهُ أَكْبَرُ", 33),
            Dhikr("أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", 100),
            Dhikr("اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", 10),
            Dhikr("لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", 100),
            Dhikr("اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ", 3),
            Dhikr("رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ نَبِيًّا", 3),
            Dhikr("بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", 3),
            Dhikr("اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ", 1)
        )
        val loaded = try {
            prefs.getString("items", null)?.let { saved -> JSONArray(saved).let { a ->
                (0 until a.length()).map { i -> a.getJSONObject(i).let { Dhikr(it.getString("text"), it.getInt("target"), it.getInt("count")) } }
            } } ?: initial
        } catch (_: Exception) { initial }
        val photos = try {
            prefs.getString("photo_items", null)?.let { saved -> JSONArray(saved).let { a ->
                (0 until a.length()).map { i -> a.getJSONObject(i).let { DhikrImage(it.getString("uri"), it.optInt("target", 33), it.optInt("count", 0)) } }
            } } ?: emptyList()
        } catch (_: Exception) { emptyList() }
        setContent { AzkarApp(loaded, photos, { saveAzkar(it) }, { savePhotos(it) }) }
    }
    private fun saveAzkar(list: List<Dhikr>) {
        val a = JSONArray(); list.forEach { a.put(JSONObject().put("text", it.text).put("target", it.target).put("count", it.count)) }
        prefs.edit().putString("items", a.toString()).apply()
    }
    private fun savePhotos(list: List<DhikrImage>) {
        val a = JSONArray(); list.forEach { a.put(JSONObject().put("uri", it.uri).put("target", it.target).put("count", it.count)) }
        prefs.edit().putString("photo_items", a.toString()).apply()
    }
}

@Composable
private fun AzkarApp(start: List<Dhikr>, startPhotos: List<DhikrImage>, onSave: (List<Dhikr>) -> Unit, onSavePhotos: (List<DhikrImage>) -> Unit) {
    val context = LocalContext.current
    var items by remember { mutableStateOf(start) }
    var photos by remember { mutableStateOf(startPhotos) }
    var selected by remember { mutableIntStateOf(0) }
    var selectedPhoto by remember { mutableIntStateOf(0) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableIntStateOf(-1) }
    var text by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("100") }
    var menuExpanded by remember { mutableStateOf(false) }
    var editingPhoto by remember { mutableIntStateOf(-1) }
    var photoTarget by remember { mutableStateOf("100") }
    val green = Color(0xFF07864B)
    val pale = Color(0xFFE7F8D8)
    fun update(newItems: List<Dhikr>) { items = newItems; onSave(newItems); if (selected >= items.size) selected = (items.size - 1).coerceAtLeast(0) }
    fun updatePhotos(newPhotos: List<DhikrImage>) { photos = newPhotos; onSavePhotos(newPhotos); if (selectedPhoto >= photos.size) selectedPhoto = (photos.size - 1).coerceAtLeast(0) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) try {
            val extension = context.contentResolver.getType(uri)?.substringAfterLast('/')?.let { ".$it" } ?: ".img"
            val destination = File(context.filesDir, "azkar_${UUID.randomUUID()}$extension")
            context.contentResolver.openInputStream(uri)?.use { input -> destination.outputStream().use { output -> input.copyTo(output) } }
            if (destination.exists() && destination.length() > 0L) { updatePhotos(photos + DhikrImage(Uri.fromFile(destination).toString(), 100)); selectedPhoto = photos.size }
        } catch (_: Exception) { }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = green, secondary = green)) {
        Box(Modifier.fillMaxSize().background(Color(0xFFE5F3F2)).padding(horizontal = 12.dp, vertical = 8.dp)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("أذكار المسلم", fontSize = 36.sp, color = Color(0xFF087B45), fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(vertical = 8.dp))
                Card(Modifier.fillMaxWidth().heightIn(min = 390.dp, max = 500.dp), shape = RoundedCornerShape(34.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("الذكر المكتوب", "الذكر المصوّر").forEachIndexed { i, label ->
                                OutlinedButton(onClick = { selectedTab = i }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(24.dp), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (selectedTab == i) pale else Color.White)) { Text(label, color = green, fontWeight = FontWeight.Bold) }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        if (selectedTab == 0) {
                            if (items.isNotEmpty()) {
                                val ix = selected.coerceIn(items.indices); val d = items[ix]
                                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text("${ix + 1} / ${items.size}", color = green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.height(12.dp))
                                        Box(Modifier.fillMaxWidth().background(pale, RoundedCornerShape(16.dp)).padding(10.dp), contentAlignment = Alignment.Center) { Text("ذكر من أذكار المسلم", color = Color.Black, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
                                        Spacer(Modifier.height(18.dp))
                                        Text(d.text, fontSize = 27.sp, lineHeight = 46.sp, textAlign = TextAlign.Center, color = Color(0xFF111111), fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(horizontal = 5.dp))
                                        Spacer(Modifier.height(16.dp))
                                        Text("${d.count}", fontSize = 42.sp, color = green, fontWeight = FontWeight.ExtraBold)
                                        Text("/ ${d.target}", fontSize = 25.sp, color = Color(0xFF111111), fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.height(8.dp))
                                        Box(Modifier.size(14.dp))
                                        Button(onClick = { val n=items.toMutableList(); if(n[ix].count < n[ix].target) n[ix]=n[ix].copy(count=n[ix].count+1); update(n) }, modifier=Modifier.fillMaxWidth().height(58.dp), shape=RoundedCornerShape(30.dp), colors=ButtonDefaults.buttonColors(containerColor=green)) { Text("تسبيح  +1", fontSize=21.sp, fontWeight=FontWeight.Bold) }
                                    }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    OutlinedButton(onClick={ val n=items.toMutableList(); n[ix]=n[ix].copy(count=0); update(n) }, modifier=Modifier.weight(1f).height(58.dp), shape=RoundedCornerShape(30.dp)) { Text("إعادة العدد", color=green, fontSize=16.sp) }
                                    OutlinedButton(onClick={ selected=(ix-1+items.size)%items.size }, modifier=Modifier.weight(1f).height(58.dp), shape=RoundedCornerShape(30.dp)) { Text("السابق", color=green, fontSize=18.sp) }
                                    OutlinedButton(onClick={ selected=(ix+1)%items.size }, modifier=Modifier.weight(1f).height(58.dp), shape=RoundedCornerShape(30.dp)) { Text("التالي", color=green, fontSize=18.sp) }
                                }
                                Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.End) {
                                    Box { TextButton(onClick={menuExpanded=true}) { Text("⋮", color=green, fontSize=28.sp) }; DropdownMenu(expanded=menuExpanded,onDismissRequest={menuExpanded=false}) {
                                        DropdownMenuItem(text={Text("إضافة ذكر")},onClick={editing=-1;text="";target="100";showEditor=true;menuExpanded=false})
                                        DropdownMenuItem(text={Text("تعديل الذكر")},onClick={editing=ix;text=d.text;target=d.target.toString();showEditor=true;menuExpanded=false})
                                        DropdownMenuItem(text={Text("تغيير العدد المستهدف")},onClick={editing=ix;text=d.text;target=d.target.toString();showEditor=true;menuExpanded=false})
                                        DropdownMenuItem(text={Text("حذف الذكر")},onClick={update(items.filterIndexed { i, _ -> i != ix });menuExpanded=false})
                                    } }
                                }
                            } else Text("لا توجد أذكار. استخدم قائمة الثلاث نقاط لإضافة ذكر.", modifier=Modifier.weight(1f), textAlign=TextAlign.Center)
                        } else {
                            if (photos.isNotEmpty()) {
                                val ix=selectedPhoto.coerceIn(photos.indices); val p=photos[ix]
                                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
                                    Text("${ix+1} / ${photos.size}", color=green, fontWeight=FontWeight.Bold)
                                    DhikrPhoto(p.uri, Modifier.fillMaxWidth().weight(1f, fill=false).heightIn(max=450.dp))
                                    Spacer(Modifier.height(8.dp)); Text("${p.count}", fontSize=40.sp, color=green, fontWeight=FontWeight.ExtraBold); Text("/ ${p.target}", fontSize=24.sp, fontWeight=FontWeight.Bold)
                                    Button(onClick={ val n=photos.toMutableList(); if(n[ix].count<n[ix].target)n[ix]=n[ix].copy(count=n[ix].count+1);updatePhotos(n) }, modifier=Modifier.fillMaxWidth().height(56.dp), shape=RoundedCornerShape(28.dp), colors=ButtonDefaults.buttonColors(containerColor=green)) { Text("تسبيح +1",fontSize=20.sp) }
                                } }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                                    OutlinedButton(onClick={val n=photos.toMutableList();n[ix]=n[ix].copy(count=0);updatePhotos(n)},modifier=Modifier.weight(1f).height(56.dp),shape=RoundedCornerShape(28.dp)){Text("إعادة العدد",color=green)}
                                    OutlinedButton(onClick={selectedPhoto=(ix-1+photos.size)%photos.size},modifier=Modifier.weight(1f).height(56.dp),shape=RoundedCornerShape(28.dp)){Text("السابق",color=green)}
                                    OutlinedButton(onClick={selectedPhoto=(ix+1)%photos.size},modifier=Modifier.weight(1f).height(56.dp),shape=RoundedCornerShape(28.dp)){Text("التالي",color=green)}
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.End) { var pm by remember { mutableStateOf(false) }; Box { TextButton(onClick={pm=true}){Text("⋮ إعدادات الصورة",color=green)}; DropdownMenu(expanded=pm,onDismissRequest={pm=false}) {
                                    DropdownMenuItem(text={Text("إضافة صورة")},onClick={imagePicker.launch(arrayOf("image/*"));pm=false})
                                    DropdownMenuItem(text={Text("تغيير العدد المستهدف")},onClick={photoTarget=p.target.toString();editingPhoto=ix;pm=false})
                                    DropdownMenuItem(text={Text("حذف الصورة")},onClick={val old=photos[ix].uri;updatePhotos(photos.filterIndexed{i,_->i!=ix});try{File(Uri.parse(old).path?:"").delete()}catch(_:Exception){};pm=false})
                                } } }
                            } else {
                                Spacer(Modifier.weight(1f)); Text("لا توجد صور أذكار بعد", color=green, fontSize=20.sp); Button(onClick={imagePicker.launch(arrayOf("image/*"))}) { Text("إضافة صورة من الهاتف") }; Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("قائمة الأذكار", modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), textAlign = TextAlign.End, color = green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 8.dp)) {
                    if (selectedTab == 0) {
                        itemsIndexed(items) { index, item ->
                            Card(Modifier.fillMaxWidth().clickable { selected = index }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = if (index == selected) Color(0xFFD0EAE7) else Color.White)) {
                                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${item.count}/${item.target}", color = green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text(item.text, modifier = Modifier.weight(1f).padding(horizontal = 12.dp), textAlign = TextAlign.End, color = Color(0xFF161616), fontSize = 18.sp, maxLines = 2)
                                    Text("⋮", color = green, fontSize = 24.sp)
                                }
                            }
                        }
                    } else {
                        itemsIndexed(photos) { index, item ->
                            Card(Modifier.fillMaxWidth().clickable { selectedPhoto = index }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = if (index == selectedPhoto) Color(0xFFD0EAE7) else Color.White)) {
                                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${item.count}/${item.target}", color = green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("الصورة ${index + 1}", modifier = Modifier.weight(1f).padding(horizontal = 12.dp), textAlign = TextAlign.End, color = Color(0xFF161616), fontSize = 18.sp)
                                    Text("⋮", color = green, fontSize = 24.sp)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { if (selectedTab == 0) { editing = -1; text = ""; target = "100"; showEditor = true } else imagePicker.launch(arrayOf("image/*")) },
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(30.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = green)
                ) {
                    Text(if (selectedTab == 0) "＋ إضافة ذكر جديد" else "＋ إضافة صورة ذكر", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        if(showEditor) AlertDialog(onDismissRequest={showEditor=false},title={Text(if(editing<0)"إضافة ذكر" else "تعديل الذكر")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
            OutlinedTextField(value=text,onValueChange={text=it},label={Text("نص الذكر")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=target,onValueChange={target=it.filter(Char::isDigit)},label={Text("العدد المستهدف")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())
        }},confirmButton={TextButton(onClick={val count=target.toIntOrNull()?.coerceAtLeast(1)?:100;if(text.isNotBlank()){val n=items.toMutableList();if(editing<0){n.add(Dhikr(text.trim(),count));selected=n.lastIndex}else n[editing]=n[editing].copy(text=text.trim(),target=count,count=0);update(n)};showEditor=false}){Text("حفظ")}},dismissButton={TextButton(onClick={showEditor=false}){Text("إلغاء")}})
        if(editingPhoto>=0) AlertDialog(onDismissRequest={editingPhoto=-1},title={Text("العدد المستهدف للصورة")},text={OutlinedTextField(value=photoTarget,onValueChange={photoTarget=it.filter(Char::isDigit)},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),label={Text("العدد")})},confirmButton={TextButton(onClick={val n=photos.toMutableList();if(editingPhoto in n.indices)n[editingPhoto]=n[editingPhoto].copy(target=photoTarget.toIntOrNull()?.coerceAtLeast(1)?:100,count=0);updatePhotos(n);editingPhoto=-1}){Text("حفظ")}},dismissButton={TextButton(onClick={editingPhoto=-1}){Text("إلغاء")}})
    }
}

@Composable
private fun DhikrPhoto(uri: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = uri) {
        value = withContext(Dispatchers.IO) {
            try { context.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
        }
    }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "صورة ذكر", modifier = modifier)
    else Box(modifier.background(Color(0xFFF3F3F3)), contentAlignment = Alignment.Center) { Text("تعذر فتح الصورة", color = Color.Gray, modifier = Modifier.padding(24.dp)) }
}
